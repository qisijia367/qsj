'''
@author: 齐斯嘉
@software: SeleniumTest
@file: mryx_shopping_message.py
@time: 2020/3/26 14:38
@desc:
'''
import unittest
from cases.base_case import BaseCase
from page.message_shop_page import MessageShopping
from page.shopping_cart_page import ShoppingCart
from common.logger import Logger
logger = Logger().logger
class ShoppingMessage(BaseCase):
    def test_shopping_message(self):
        '''
        进入商品详情页面购物
        :return:
        '''
        shop = MessageShopping(self.driver)
        shop.click_one_massage()#进入商品详情页
        shop.click_add_gwc_tbotton()#点击加入购物车
        shop.click_anthor_message()#进入商品详情页
        shop.click_add_gwc_tbotton()#点击加入购物车
        shop.cilck_goto_gwc_botton()#进入购物车
        car = ShoppingCart(self.driver)
        gwc_money = car.get_gwc_money()  # 获取购物车的总价
        logger.info(gwc_money)
        car.click_close_botton()  # 点击去结算，进入到结算页面
        order_money = car.get_order_money()  # 获取订单的总价
        logger.info(order_money)
        self.assertEqual(gwc_money, order_money)  # 判断购物车与订单
        self.driver.press_keycode(4)#为清空购物车做准备
        car.click_out() #返回至购物车页面

if __name__ == "__main__":
    unittest.main()