'''
@author: 齐斯嘉
@software: SeleniumTest
@file: mryx_zero_user.py
@time: 2020/3/26 19:03
@desc:
'''
import unittest
from cases.base_case import BaseCase
from page.home_shop_page import HomeShop
from page.shopping_cart_page import ShoppingCart
from page.my_setting_page import SettingPage
from common.logger import Logger
logger = Logger().logger
class ZeroUser(BaseCase):
    def test_zero_user(self):
        '''
        退出登录后，无登录状态购物
        :return:
        '''
        my = SettingPage(self.driver)
        my.click_my()#进入我的页面
        my.cilck_setting()#进入设置页面
        my.click_out_user()#退出登录
        text = my.get_text_out()
        logger.info(text)
        self.assertEqual('登录/注册',text)#判断是否退出登录
        my.cilck_home()#进入商城首页
        add = HomeShop(self.driver)
        add.click_two_shopping()#添加两件特卖商品到购物车
        add.click_classify()#进入分类页面
        add.click_snacks_shopping()#添加分类中的两件商品到购物车
        add.click_gwc_icon()#进入购物车页面
        car = ShoppingCart(self.driver)
        car.click_close_botton()#点击去结算
        title = car.get_login_text()#获取登录页面的信息
        logger.info(title)
        self.assertEqual('登录',title)#判断页面是否跳转成功
        self.driver.press_keycode(4)

if __name__ == "__main__" :
    unittest.main()