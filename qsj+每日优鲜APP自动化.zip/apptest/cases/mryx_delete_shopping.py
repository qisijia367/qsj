'''
@author: 齐斯嘉
@software: SeleniumTest
@file: mryx_delete_shopping.py
@time: 2020/3/26 15:51
@desc:
'''
import unittest
from cases.base_case import BaseCase
from page.home_shop_page import HomeShop
from page.shopping_cart_page import ShoppingCart
from common.logger import Logger
logger = Logger().logger
class DeleteShopping(BaseCase):
    def test_delete_shopping(self):
        '''
        购物车删除商品
        :return:
        '''
        add = HomeShop(self.driver)
        add.click_five_shopping()#添加五件商品至购物车
        add.click_gwc_icon() # 进入购物车页面
        car = ShoppingCart(self.driver)
        one_money = car.get_gwc_money()  #获取当前购物车的总价
        logger.info(one_money)
        car.click_long_press()#单个删除商品
        car.click_sure_botton()#确认删除
        two_money = car.get_gwc_money()  #获取当前购物车的总价
        logger.info(two_money)
        self.assertNotEqual(one_money,two_money)#判断删除前后总价不相等
        car.cilck_gwc_checkbox()#取消选择第二件第四件商品
        car.click_delete_botton()#点击删除按钮
        car.click_sure_botton()#点击确认
        car.click_all()  # 点击全选
        three_money = car.get_gwc_money()#获取当前购物车的总价
        logger.info(three_money)
        self.assertNotEqual(three_money, two_money)#判断删除前后总价不相等
        car.click_delete_botton()#点击删除按钮
        car.click_sure_botton()#确认删除
        four_money = car.get_gwc_money()#获取当前购物车的总价
        logger.info(four_money)
        self.assertNotEqual(three_money, four_money)#判断删除前后总价不相等
        car.click_home()  # 方便tearDown清理购物车环境

if __name__ == "__main__" :
    unittest.main()