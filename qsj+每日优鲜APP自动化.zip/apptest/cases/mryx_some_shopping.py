'''
@author: 齐斯嘉
@software: SeleniumTest
@file: mryx_some_shopping.py
@time: 2020/3/26 14:55
@desc:
'''
import unittest
from cases.base_case import BaseCase
from page.home_shop_page import HomeShop
from page.shopping_cart_page import ShoppingCart
from common.logger import Logger
logger = Logger().logger
class SomeShopping(BaseCase):
    def test_some_shopping(self):
        '''
        购物车选择部分商品结算
        :return:
        '''
        add = HomeShop(self.driver)
        add.click_five_shopping()#添加五件商品至购物车
        add.click_gwc_icon()#进入购物车
        car = ShoppingCart(self.driver)
        car.cilck_gwc_checkbox()#取消选中第二件和第四件商品
        gwc_money = car.get_gwc_money()  # 获取购物车的总价
        logger.info(gwc_money)
        car.click_close_botton()  # 点击去结算，进入到结算页面
        order_money = car.get_order_money()  # 获取订单的总价
        logger.info(order_money)
        self.assertEqual(gwc_money, order_money)  # 判断购物车与订单
        self.driver.press_keycode(4)#为清空购物车做准备
        car.click_out()#返回至购物车页面
        car.click_all()#全选商品

if __name__ == "__main__":
    unittest.main()