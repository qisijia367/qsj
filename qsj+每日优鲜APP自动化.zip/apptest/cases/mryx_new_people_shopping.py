'''
@author: 齐斯嘉
@software: SeleniumTest
@file: mryx_new_people_shopping.py
@time: 2020/3/26 10:11
@desc:
'''
import unittest
from cases.base_case import BaseCase
from page.new_people_page import Newpeople
from page.shopping_cart_page import ShoppingCart
from common.logger import Logger
logger = Logger().logger
class NewPeopleShopping(BaseCase):
    def test_new_people(self):
        '''
        新人专享页面购物
        :return:
        '''
        shop = Newpeople(self.driver)
        shop.click_new_shopping()#进入新人专享页面
        shop.click_commodity()#选择头四件商品
        shop.click_new_shopping_cart()#点击购物车图标进入购物车
        car = ShoppingCart(self.driver)
        car.click_one_shopping_gwc()#点击购物车第一件商品的对话框
        car.click_delete_botton()#点击购物车右上角的删除
        car.click_sure_botton()#确认删除
        car.click_one_shopping_gwc()#选中第一件商品
        gwc_money = car.get_gwc_money()#获取购物车的总价
        logger.info(gwc_money)
        car.click_close_botton()#点击去结算，进入到结算页面
        order_money = car.get_order_money()#获取订单的总价
        logger.info(order_money)
        self.assertEqual(gwc_money,order_money)#判断购物车与订单
        self.driver.press_keycode(4)#为清空购物车做准备
        car.click_out()  # 返回至购物车页面

if __name__ == "__main__" :
    unittest.main()
