'''
设置用例执行前后的setUp和tearDown
'''
import unittest
from common.driver import driver
from page.shopping_cart_page import ShoppingCart
class BaseCase(unittest.TestCase):
    #用例执行前
    def setUp(self):
        self.driver = driver()
        self.driver.implicitly_wait(30)#隐式等待30秒

    #用例执行完
    def tearDown(self):
        '''
        用例执行完成后清空购物车所有商品
        :return:
        '''
        car = ShoppingCart(self.driver)
        car.click_delete_botton()  # 点击购物车右上角的删除
        car.click_sure_botton()  # 确认删除
        self.driver.quit()