'''
@author: 齐斯嘉
@software: SeleniumTest
@file: mryx_cart_skip.py
@time: 2020/3/26 17:07
@desc:
'''
import unittest
from cases.base_case import BaseCase
from page.home_shop_page import HomeShop
from page.shopping_cart_page import ShoppingCart
from page.new_people_page import Newpeople
from common.logger import Logger
logger = Logger().logger
class CartSkip(BaseCase):
    def test_cart_skip(self):
        '''
        购物车跳转凑单页面和商品详情页面，以及在逛逛页面
        :return:
        '''
        add = HomeShop(self.driver)
        add.click_two_shopping()#添加两件特卖商品至购物车
        new = Newpeople(self.driver)
        new.click_new_shopping()#进入新人专享页面
        new.click_commodity()#添加新人专享商品至购物车
        self.driver.press_keycode(4)
        add.click_snacks()#进入休闲食品页面
        add.click_snacks_shopping()#添加休闲食品至购物车
        add.click_gwc_icon()#进入购物车
        car = ShoppingCart(self.driver)
        car.click_message()#进入商品详情页
        text_massage = car.get_message_text()
        logger.info(text_massage)
        self.assertEqual("加入购物车",text_massage)#判断页面是否跳转成功
        self.driver.press_keycode(4)
        car.click_more_one()#进入再逛逛页面
        title = car.get_title_text()#获取页面标题名
        logger.info(title)
        self.assertEqual('参加活动商品列表',title)#判断页面是否跳转成功
        self.driver.press_keycode(4)
        car.click_more_two()#进入去凑单页面
        name = car.get_title_text()#获取页面标题名
        logger.info(name)
        self.assertEqual('参加活动商品列表', name)  # 判断页面是否跳转成功
        self.driver.press_keycode(4)

if __name__ == "__main__" :
    unittest.main()