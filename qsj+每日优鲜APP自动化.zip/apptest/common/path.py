'''
@author: 齐斯嘉
@software: SeleniumTest
@file: path.py
@time: 2020/3/26 20:23
@desc:
'''
import os
#设置文件路径
path = os.path.abspath('.')
current_path = os.path.dirname(path)
CASES_PATH = os.path.join(current_path, 'cases')
REPORT_PATH = os.path.join(current_path, 'report')
LOG_PATH = os.path.join(current_path, 'log')
DATA_PATH = os.path.join(current_path, 'datas')