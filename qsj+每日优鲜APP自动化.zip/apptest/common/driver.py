'''
@author: 齐斯嘉
@software: SeleniumTest
@file: driver.py
@time: 2020/3/26 10:37
@desc:
'''
from appium import webdriver
def driver():
    '''
    连接设备打开每日优选app并返回driver
    :return:
    '''
    desired_capabilities = {
        'platformName': 'Android',
        'deviceName': '127.0.0.1:62001',
        'platformVersion': '5.1.1',
        'appPackage': 'cn.missfresh.application',
        'appActivity': 'cn.missfresh.module.base.main.view.SplashActivity',
        'noReset': True
    }
    driver=webdriver.Remote("http://localhost:4723/wd/hub", desired_capabilities)
    return driver
