'''
@author: 齐斯嘉
@software: SeleniumTest
@file: utills.py
@time: 2020/3/24 22:51
@desc:
'''
# 获得机器屏幕大小x,y
def getSize(dr):
	x = dr.get_window_size()['width']
	y = dr.get_window_size()['height']
	return (x, y)  #(720,1280)


# 屏幕向上滑动
def swipeUp(dr, t):
	l = getSize(dr) #(720,1280)
	x1 = int(l[0] * 0.5)  # x坐标  360
	y1 = int(l[1] * 0.92)  # 起始y坐标  960
	y2 = int(l[1] * 0.25)  # 终点y坐标  320
	dr.swipe(x1, y1, x1, y2, t)


# 屏幕向下滑动
def swipeDown(dr, t):
	l = getSize(dr)
	x1 = int(l[0] * 0.5)  # x坐标
	y1 = int(l[1] * 0.25)  # 起始y坐标  320
	y2 = int(l[1] * 0.75)  # 终点y坐标  960
	dr.swipe(x1, y1, x1, y2, t)


# 屏幕向左滑动
def swipLeft(dr, t):
	l = getSize(dr)
	x1 = int(l[0] * 0.75)
	y1 = int(l[1] * 0.5)
	x2 = int(l[0] * 0.05)
	dr.swipe(x1, y1, x2, y1, t)


# 屏幕向右滑动
def swipRight(dr, t):
	l = getSize(dr)
	x1 = int(l[0] * 0.05)
	y1 = int(l[1] * 0.5)
	x2 = int(l[0] * 0.75)
	dr.swipe(x1, y1, x2, y1, t)


# 屏幕快速向右滑动
def flickSwipRight(dr):
	l = getSize(dr)
	x1 = int(l[0] * 0.05)
	y1 = int(l[1] * 0.5)
	x2 = int(l[0] * 0.75)
	dr.flick(x1, y1, x2, y1)