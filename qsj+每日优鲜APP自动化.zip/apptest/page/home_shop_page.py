'''
@author: 齐斯嘉
@software: SeleniumTest
@file: home_shop_page.py
@time: 2020/3/26 10:06
@desc:
'''
from appium.webdriver.common.mobileby import MobileBy as By
from appium.webdriver.common.touch_action import TouchAction
from page.base_page import BasePage
class HomeShop(BasePage):
    '''
    主页购物操作
    '''
    #主页开业特卖商品
    for i in range(1,6):
        add_shop_locator = (By.XPATH,'//android.support.v7.widget.RecyclerView[@resource-id=\"cn.missfresh.application:id/rv_product\"]/android.widget.LinearLayout[{}]/android.widget.RelativeLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[2]/android.widget.RelativeLayout[1]/android.widget.ImageView[1]'.format(i))

    #定位下边框购物车图标
    gwc_locator = (By.XPATH,'//android.widget.LinearLayout[@resource-id=\"cn.missfresh.application:id/cv_main_bottom_tab_layout\"]/android.widget.FrameLayout[4]/android.widget.LinearLayout[1]/android.widget.RelativeLayout[1]/android.widget.LinearLayout[1]/android.widget.ImageView[1]')

    #定位商品列表第一件商品
    for n in range(1,3):
        shop_one_locator = (By.XPATH,'//android.support.v7.widget.RecyclerView[@resource-id=\"cn.missfresh.application:id/recycler_view\"]/android.widget.RelativeLayout[{}]/android.widget.FrameLayout[2]/android.widget.RelativeLayout[2]/android.widget.FrameLayout[1]/android.widget.ImageView[1]'.format(n))

    #定位下边框的分类图标
    classify_locator = (By.XPATH,'//android.widget.LinearLayout[@resource-id=\"cn.missfresh.application:id/cv_main_bottom_tab_layout\"]/android.widget.FrameLayout[2]/android.widget.LinearLayout[1]/android.widget.RelativeLayout[1]/android.widget.LinearLayout[1]/android.widget.ImageView[1]')

    #定位休闲零食
    snacks_locator = (By.XPATH,'//android.support.v7.widget.RecyclerView[@resource-id=\"cn.missfresh.application:id/rv_small_diamond\"]/android.widget.LinearLayout[3]/android.widget.ImageView[1]')

    #休闲零食商品
    for m in range(1,3):
        bcw_one_locator = (By.XPATH,'//android.support.v7.widget.RecyclerView[@resource-id=\"cn.missfresh.application:id/homepage_product_rcv\"]/android.widget.RelativeLayout[{}]/android.widget.FrameLayout[2]/android.widget.RelativeLayout[2]/android.widget.FrameLayout[1]/android.widget.ImageView[1]'.format(m))

    def click_five_shopping(self):
        '''
        添加五件特卖商品至购物车
        :return:
        '''
        self.find_element(self.add_shop_locator).click()

    def click_gwc_icon(self):
        #点击下边框购物车图标，进入购物车页面
        self.find_element(self.gwc_locator).click()

    def click_two_shopping(self):
        #添加特卖两件商品至购物车
        self.find_element(self.add_shop_locator).click()

    def slide_screen(self):
        #滑动主页屏幕至商品列表面
        size = self.driver.get_window_size()  # 获取设备页面大小
        x = size.get('width')  # 宽
        y = size.get('height')  # 长
        x_shop = x / 2  # 获取的x轴坐标
        y_shop_star = y * (1756 / 1920)  # 获取y轴的起始坐标
        y_shop_end = y * 0.25  # 获取y轴的结束坐标
        action = TouchAction(self.driver)  # 实例化
        action.press(x=x_shop, y=y_shop_star)  # 点击起始坐标
        action.move_to(x=x_shop, y=y_shop_end)  # 移动到结束坐标
        action.release()  # 松开点击
        action.perform()  # 上传点击操作

    def click_two_list_shopping(self):
        #添加两件商品列表中的商品至购物车
        self.find_element(self.shop_one_locator).click()

    def click_classify(self):
        #点击进入分类页面
        self.find_element(self.classify_locator).click()

    def click_snacks(self):
        #点击进入休闲食品页面
        self.find_element(self.snacks_locator).click()

    def click_snacks_shopping(self):
        #添加休闲商品至购物车
        self.find_element(self.bcw_one_locator).click()
