'''
@author: 齐斯嘉
@software: SeleniumTest
@file: new_people_page.py
@time: 2020/3/26 10:06
@desc:
'''
from appium.webdriver.common.mobileby import MobileBy as By
from appium.webdriver.common.touch_action import TouchAction
from page.base_page import BasePage
from time import sleep
class Newpeople(BasePage):
    '''
    新人专享页面购物操作
    :return:
    '''
    #定位新人专享页面
    new_exclusive_locator = (By.ID, 'cn.missfresh.application:id/product_image')
    #新人专享页面第一件商品
    for i in range(2,6):
        newshop_locator = (By.XPATH,'//android.view.View/android.view.View[{}]/android.view.View[1]/android.view.View[5]/android.view.View[1]/android.widget.Image[1]'.format(i))

    def click_new_shopping(self):
        #点击新人专享，进入新人专享页面
        self.find_element(self.new_exclusive_locator).click()

    def click_commodity(self):
        #进入新人专享页面，添加头四件商品
        self.find_element(self.newshop_locator).click()


    def click_new_shopping_cart(self):
        #点击新人专享中的购物车图标
        size = self.driver.get_window_size()  # 获取设备页面大小
        x = size.get('width')  # 宽
        y = size.get('height')  # 长
        x_shop = x * (94 / 1080)  # 获取购物车图标的x轴坐标
        y_shop = y * (1770 / 1920)  # 获取购物车图标的y轴坐标
        action = TouchAction(self.driver)  # 实例化
        action.tap(x=x_shop, y=y_shop)  # 点击购物车图标
        action.perform()  # 上传点击操作