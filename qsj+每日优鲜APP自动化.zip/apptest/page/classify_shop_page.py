'''
@author: 齐斯嘉
@software: SeleniumTest
@file: classify_shop_page.py
@time: 2020/3/26 10:07
@desc:
'''
from appium.webdriver.common.mobileby import MobileBy as By
from page.base_page import BasePage
class Classify(BasePage):
    '''
    分类页面操作
    '''
    #定位熟食餐饮的位置
    deli_locator = (By.ANDROID_UIAUTOMATOR, 'new UiSelector().text("熟食餐饮")')
    #定位商品
    for i in range(2,5):
        shop_deli_locator = (By.XPATH,'//android.support.v7.widget.RecyclerView[@resource-id=\"cn.missfresh.application:id/homepage_product_rcv\"]/android.widget.RelativeLayout[{}]/android.widget.FrameLayout[2]/android.widget.RelativeLayout[2]/android.widget.FrameLayout[1]/android.widget.ImageView[1]'.format(i))

    def click_deli(self):
        #点击分类进入分类页面
        self.find_element(self.deli_locator).click()

    def cilck_deli_two(self):
        #点击两件商品至购物车
        self.find_element(self.shop_deli_locator).click()