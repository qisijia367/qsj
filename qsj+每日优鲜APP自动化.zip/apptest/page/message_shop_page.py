'''
@author: 齐斯嘉
@software: SeleniumTest
@file: message_shop_page.py
@time: 2020/3/26 14:39
@desc:
'''
from appium.webdriver.common.mobileby import MobileBy as By
from page.base_page import BasePage
class MessageShopping(BasePage):
    '''
    从商品详情页添加商品到购物车
    '''
    #定位第一件商品
    commodity_locator = (By.XPATH,'//android.support.v7.widget.RecyclerView[@resource-id=\"cn.missfresh.application:id/rv_product\"]/android.widget.LinearLayout[2]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.ImageView[1]')
    #定位添加到购物车按钮
    add_gwc_massger_locator = (By.XPATH, '//android.widget.TextView[@resource-id=\"cn.missfresh.application:id/tv_add_cart\"]')
    #定位商品详情页推荐的其他商品
    commodity_shop_locator = (By.XPATH,'//android.support.v7.widget.RecyclerView[@resource-id=\"cn.missfresh.application:id/recyclerView_detail_recommend\"]/android.widget.LinearLayout[3]/android.widget.FrameLayout[1]/android.widget.FrameLayout[1]/android.widget.ImageView[1]')
    #定位购物车图标
    add_gwc_locator = (By.XPATH, '//android.widget.ImageView[@resource-id=\"cn.missfresh.application:id/iv_cart_icon\"]')

    def click_one_massage(self):
        #进入商品的详情页
        self.find_element(self.commodity_locator).click()

    def click_add_gwc_tbotton(self):
        #点击添加购物车按钮
        self.find_element(self.add_gwc_massger_locator).click()

    def click_anthor_message(self):
        #点击进入其他商品的详情页
        self.find_element(self.commodity_shop_locator).click()

    def cilck_goto_gwc_botton(self):
        #点击购物车图标，进入购物车
        self.find_element(self.add_gwc_locator).click()