'''
@author: 齐斯嘉
@software: SeleniumTest
@file: shopping_cart_page.py
@time: 2020/3/26 10:08
@desc:
'''
from appium.webdriver.common.mobileby import MobileBy as By
from page.base_page import BasePage
from appium.webdriver.common.touch_action import TouchAction
from time import sleep
class ShoppingCart(BasePage):
    '''
    购物车页面操作
    '''
    # 购物车第一件商品勾选框
    check_locator = (By.XPATH,'//android.support.v7.widget.RecyclerView[@resource-id=\"cn.missfresh.application:id/rcv_product\"]/android.widget.RelativeLayout[2]/android.widget.ImageView[1]')
    # 购物车右上角删除键
    delete_locator = (By.XPATH, '//android.widget.TextView[@resource-id=\"cn.missfresh.application:id/tv_delete\"]')
    # 确认删除
    delete_sure_locator = (By.XPATH, '//android.widget.TextView[@resource-id=\"cn.missfresh.application:id/tv_ensure\"]')
    # 去结算按钮定位
    go_close_locator = (By.XPATH, '//android.widget.TextView[@resource-id=\"cn.missfresh.application:id/tv_checkout\"]')
    #获取购物车的总价
    gwc_money_locator = (By.XPATH,'//android.widget.TextView[@resource-id=\"cn.missfresh.application:id/tv_price\"]')
    #订单页面的总价
    order_money_locator = (By.XPATH,'//android.widget.TextView[@resource-id=\"cn.missfresh.application:id/tv_amount\"]')
    #订单页面返回至购物车页面
    out_locator = (By.XPATH,'//android.widget.TextView[@resource-id=\"cn.missfresh.application:id/tv_double_btn_cancel\"]')
    #购物车第一件商品减号
    reduce_one_locator = (By.XPATH,'//android.support.v7.widget.RecyclerView[@resource-id=\"cn.missfresh.application:id/rcv_product\"]/android.widget.RelativeLayout[1]/android.widget.ImageView[4]')
    #购物车第二件商品加号
    add_one_locator = (By.XPATH,'//android.support.v7.widget.RecyclerView[@resource-id=\"cn.missfresh.application:id/rcv_product\"]/android.widget.RelativeLayout[2]/android.widget.ImageView[5]')
    #购物车第三件商品减号
    reduce_delete_locator = (By.XPATH,'//android.support.v7.widget.RecyclerView[@resource-id=\"cn.missfresh.application:id/rcv_product\"]/android.widget.RelativeLayout[3]/android.widget.ImageView[4]')
    #定位购物车第二件商品的勾选框
    delete_many_one_locator = (By.XPATH,'//android.support.v7.widget.RecyclerView[@resource-id=\"cn.missfresh.application:id/rcv_product\"]/android.widget.RelativeLayout[2]/android.widget.ImageView[1]')
    #定位购物车第四件商品的勾选框
    delete_many_two_locator = (By.XPATH,'//android.support.v7.widget.RecyclerView[@resource-id=\"cn.missfresh.application:id/rcv_product\"]/android.widget.RelativeLayout[4]/android.widget.ImageView[1]')
    #定位全部选择按钮
    all_locator = (By.XPATH,'//android.widget.ImageView[@resource-id=\"cn.missfresh.application:id/cb_select_all\"]')
    #定位购物车第二件商品
    delete_one_locator = (By.XPATH,'//android.support.v7.widget.RecyclerView[@resource-id=\"cn.missfresh.application:id/rcv_product\"]/android.widget.RelativeLayout[2]/android.widget.ImageView[2]')
    #点击猜你喜欢的商品
    home_locator = (By.XPATH,'//android.support.v7.widget.RecyclerView[@resource-id=\"cn.missfresh.application:id/rcv_product\"]/android.widget.RelativeLayout[2]/android.widget.ImageView[3]')
    #定位购物车第一个商品的位置
    detail_locator = (By.XPATH,'//android.support.v7.widget.RecyclerView[@resource-id=\"cn.missfresh.application:id/rcv_product\"]/android.widget.RelativeLayout[1]/android.widget.ImageView[2]')
    #定位商品详情页的加入购物车
    message_cart_locator = (By.XPATH,'//android.widget.TextView[@resource-id=\"cn.missfresh.application:id/tv_add_cart\"]')
    #定位再逛逛
    more_one_shop_locator = (By.ANDROID_UIAUTOMATOR, 'new UiSelector().text("再逛逛")')
    #定位去凑单
    more_two_shop_locator = (By.ANDROID_UIAUTOMATOR, 'new UiSelector().text("去凑单")')
    #定位页面标题名称
    title_locator = (By.XPATH,'//android.widget.TextView[@resource-id=\"cn.missfresh.application:id/tv_title_bar_center_txt\"]')
    #定位购物车跳转登录页面的文本信息
    login_text_locator = (By.XPATH,'/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.view.View/android.widget.TextView[1]')

    def click_one_shopping_gwc(self):
        #点击购物车第一件商品的勾选框
        self.find_element(self.check_locator).click()

    def click_delete_botton(self):
        #点击购物车右上角删除键
        self.find_element(self.delete_locator).click()

    def click_sure_botton(self):
        #确定删除按钮
        self.find_element(self.delete_sure_locator).click()

    def click_close_botton(self):
        #点击购物车中的去结算
        self.find_element(self.go_close_locator).click()

    def get_gwc_money(self):
        #获取购物车的商品总价
        return  self.find_element(self.gwc_money_locator).text

    def get_order_money(self):
        #获取订单页面的商品总价
        return self.find_element(self.order_money_locator).text

    def click_out(self):
        #订单页面返回至购物车页面
        self.find_element(self.out_locator).click()

    def click_one_reduce(self):
        #点击购物车第一件商品的减号
        self.find_element(self.reduce_one_locator).click()

    def click_one_add(self):
        #点击购物车第二件商品的加号
        self.find_element(self.add_one_locator).click()

    def cilck_three_reduce(self):
        #点击购物车第三件商品的减号,直至删除
            self.find_element(self.reduce_delete_locator).click()

    def cilck_gwc_checkbox(self):
        #点击购物车第二件商品的勾选框
        self.find_element(self.delete_many_one_locator).click()

    def click_all(self):
        #点击购物车中的全部按钮
        self.find_element(self.all_locator).click()

    def click_long_press(self):
        '''
        模仿长时间按压，单个删除商品
        :return:
        '''
        action = TouchAction(self.driver)
        action.long_press(self.find_element(self.delete_one_locator), 2000)  # 长按删除第二个商品
        action.release()
        action.perform()

    def click_home(self):
        #添加猜你喜欢的商品至购物车
        self.find_element(self.home_locator).click()

    def click_message(self):
        #点击购物车第一个商品跳转至商品详情页
        self.find_element(self.detail_locator).click()

    def get_message_text(self):
        #获取商品详情页的加入购物车文本信息
        return self.find_element(self.message_cart_locator).text

    def click_more_one(self):
        #点击购物车的再逛逛按钮
        self.find_element(self.more_one_shop_locator).click()

    def click_more_two(self):
        #点击购物车的去凑单按钮
        self.find_element(self.more_two_shop_locator).click()

    def get_title_text(self):
        #获取页面标题名称
        return self.find_element(self.title_locator).text

    def get_login_text(self):
        #获取登录页面的文本信息
        return self.find_element(self.login_text_locator).text