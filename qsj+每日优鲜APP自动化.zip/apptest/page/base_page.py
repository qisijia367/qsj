'''
@author: 齐斯嘉
@software: SeleniumTest
@file: base_page.py
@time: 2020/3/26 10:16
@desc:
'''
class BasePage():
    """
    所有页面类的基类
    """
    def __init__(self,driver):
        self.driver = driver

    def find_element(self,locator):
        '''
        重新封装find_element()方法
        :param locator:
        :return:
        '''
        return self.driver.find_element(*locator)