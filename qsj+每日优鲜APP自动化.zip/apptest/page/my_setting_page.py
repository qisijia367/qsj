'''
@author: 齐斯嘉
@software: SeleniumTest
@file: my_setting_page.py
@time: 2020/3/26 10:09
@desc:
'''
from appium.webdriver.common.mobileby import MobileBy as By
from page.base_page import BasePage
from appium.webdriver.common.touch_action import TouchAction
class SettingPage(BasePage):
    '''
    我的页面进入设置退出用户的操作
    '''
    #定位我的页面
    my_locator = (By.ANDROID_UIAUTOMATOR, 'new UiSelector().text("我的")')
    #定位设置按钮
    setting_locator = (By.XPATH,'/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.View/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.LinearLayout[2]/android.support.v7.widget.RecyclerView/android.widget.LinearLayout[8]/android.widget.RelativeLayout/android.widget.ImageView')
    #定位退出后的文本信息
    out_text_locator = (By.XPATH,'/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.view.View/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.RelativeLayout/android.widget.RelativeLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.TextView')
    #定位首页
    home_locator = (By.XPATH,'//android.widget.LinearLayout[@resource-id=\"cn.missfresh.application:id/cv_main_bottom_tab_layout\"]/android.widget.FrameLayout[1]/android.widget.LinearLayout[1]/android.widget.RelativeLayout[1]/android.widget.LinearLayout[1]/android.widget.ImageView[1]')

    def click_my(self):
        #点击进入我的页面
        self.find_element(self.my_locator).click()

    def cilck_setting(self):
        #点击进入设置页面
        self.find_element(self.setting_locator).click()

    def click_out_user(self):
        #点击退出登录
        size = self.driver.get_window_size()  # 获取设备页面大小
        x = size.get('width')  # 宽
        y = size.get('height')  # 长
        x = x / 2  # 获取的x轴坐标
        y = y * (1100 / 1920)  # 获取y轴的坐标
        action = TouchAction(self.driver)  # 实例化
        action.tap(x=x, y=y)
        action.perform()  # 上传点击操作，退出登录

    def get_text_out(self):
        #获取退出后的文本信息
        return self.find_element(self.out_text_locator).text

    def cilck_home(self):
        #进入商城首页
        self.find_element(self.home_locator).click()