'''
@author: 齐斯嘉
@software: SeleniumTest
@file: run.py
@time: 2020/3/19 21:25
@desc:
'''
import unittest
from BeautifulReport import BeautifulReport
import time
from common.path import *
from page.login_page import CRMUser
from common.drive import Chrome
from common.read_datas import creat_cookies

lp = CRMUser(Chrome())
lp.open()
lp.get_login("admin", "123456")#登录成功
cookies = lp.get_cookies()#获取登录的cookie
cookies = creat_cookies(cookies[0])#获取cookie中的name和value
file_name = os.path.join(DATA_PATH, 'cookies.ini')#获得存放文件的绝对路径
with open(file_name,"w") as f:
    f.write(str(cookies))#将cookie转成字符串存在文件中
lp.driver.quit()#退出浏览器

discover = unittest.defaultTestLoader.discover(CASES_PATH,pattern='crm*.py')#设置用例的执行范围
time_format = time.strftime("%Y-%m-%d %H_%M_%S")#格式化时间
filename = "crm_{}.html".format(time_format)#设置报告文件名称
BeautifulReport(discover).report(description="CRM测试用例",
                                 report_dir='report',
                                 filename=filename)#执行用例并设定报告名称