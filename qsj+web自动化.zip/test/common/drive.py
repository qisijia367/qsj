from selenium import webdriver
def Chrome():
    '''
    封装Chrome浏览器
    '''
    driver = webdriver.Chrome()#实例化
    driver.maximize_window()#最大化浏览器窗口
    return driver