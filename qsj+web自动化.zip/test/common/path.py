'''
@author: 齐斯嘉
@software: SeleniumTest
@file: path.py
@time: 2020/3/20 14:03
@desc:
'''
import os
path = os.path.abspath('.')
current_path = os.path.dirname(path)
CASES_PATH = os.path.join(current_path,'cases')
DATA_PATH = os.path.join(current_path, 'datas')
COMMON_PATH = os.path.join(current_path,'common')
PAGE_PATH = os.path.join(current_path,'page')
REPORT_PATH = os.path.join(current_path, 'report')
LOG_PATH = os.path.join(current_path, 'log')
HOST = "http://192.168.3.42"
