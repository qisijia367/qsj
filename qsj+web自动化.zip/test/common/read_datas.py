'''
读取文档中的参数
'''
import csv # 引入csv包
from common.path import *
import os
def read_datas_users(name):
    '''
    从csv中读取参数，将参数组装成元组并输出
    :return:
    '''
    file = os.path.join(DATA_PATH, name)#组装文件路径
    with open(file, "r", encoding="utf-8") as f:
        data = csv.reader(f)#读取整个csv文件
        lst = []
        for user in data:
            lst.append(tuple(user))#将一行数据组成的元组追加到列表
        return lst[1:] #返回元组组成的列表

def creat_cookies(dct,keys=None,default=None):
    '''
    获取cookie字典，获取其中的name和value的值，并返回
    :param dct:
    :param keys:
    :param default:
    :return:
    '''
    if keys is None:
        keys = ["name","value"]
    dt = {}
    for key in keys:
        dt[key] = dct.get(key)
    return dt

def get_cookie(filename):
    '''
    获取存放cookie的文件地址，并读取其中的数据以字典的形式返回
    :param filename:
    :return:
    '''
    file = os.path.join(DATA_PATH, filename)
    with open(file, "r+", encoding="utf-8") as f:
        cookies = f.readline()
        return eval(cookies)