'''
定义登录页面类
'''
from page.base_page import CRMFather
from selenium.webdriver.common.by import By
class CRMUser(CRMFather):
    # 定义定位器
    username_locator = (By.NAME,"name")
    password_locator = (By.NAME, "password")
    botton_locator = (By.NAME, "submit")

    def get_username(self,username):
        '''
        输入用户名
        :param username: 用户名
        :return:
        '''
        self.find_element(self.username_locator).send_keys(username)

    def get_password(self,password):
        '''
        输入密码
        :param password: 密码
        :return:
        '''
        self.find_element(self.password_locator).send_keys(password)

    def get_botton(self):
        '''
        点击登录按钮
        :param submit: 登录
        :return:
        '''
        self.find_element(self.botton_locator).click()

    def get_login(self,username,password):
        '''
        完成登录操作
        :param username:
        :param password:
        :return:
        '''
        self.find_element(self.username_locator).send_keys(username)
        self.find_element(self.password_locator).send_keys(password)
        self.find_element(self.botton_locator).click()

    def get_cookies(self):
        return self.driver.get_cookies()