'''
主页类
'''
from page.base_page import CRMFather
from selenium.webdriver.common.by import By
class CRMUserTest(CRMFather):
    # 定义定位器
    username_locator = (By.CSS_SELECTOR,"li.dropdown:nth-child(6) > a:nth-child(1)")#定位主页右上角用户名
    user_down_locator = (By.CSS_SELECTOR,".table > tbody:nth-child(3) > tr:nth-child(2) > td:nth-child(1)")#定位个人信息中的职位
    news_locator = (By.CSS_SELECTOR,".span9")#定位部门信息
    gzt_search_locator = (By.CSS_SELECTOR,".middle-content")#定位工作台动态信息

    # 获取登录用户名信息
    def get_username(self):
        return self.find_element(self.username_locator).text.strip()

    #获取个人信息页面信息
    def get_user(self):
        return self.find_element(self.user_down_locator).text

    # 获取工作台页面信息
    def get_news(self):
        return self.find_element(self.news_locator)

    # 获取工作台动态信息
    def get_gzt_search(self):
        return self.find_element(self.gzt_search_locator)