'''
修改系统基本设置信息，包括默认信息中的系统名，系统描述等，
以及安全与调试中的文件格式的修改，其他设置中关于客户、线索等方面的设置
'''
from page.base_page import CRMFather
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select
class CRMChangeWordsData(CRMFather):
    '''
    系统设置页面定位器
    '''
    name_locator = (By.ID, "name")#定位系统名称
    describe_locator = (By.ID, "description")#定位系统描述
    picture_locator = (By.NAME, "logo")#定位系统logo
    provice_locator = (By.ID, "state")#定位省份
    city_locator = (By.ID, "city")#定位城市
    time_pact_locator = (By.NAME, "contract_alert_time")#定位合同提醒时间
    name_pact_locator = (By.NAME, "contract_custom")#定位合同前缀名
    change_locator =  (By.XPATH, "//input[@name='task_model' and @value='1']")#定位任务分配模式
    change_client_time_locator = (By.ID, "customer_outdays")#定位客户池回收周期
    time_client_locator = (By.NAME, "customer_limit_condition")#定位客户领取周期
    client_number_locator = (By.ID, "customer_limit_counts")#定位客户领取次数
    clue_time_locator = (By.ID, "leads_outdays")#定位线索池回收周期
    save_locator = (By.TAG_NAME, ".btn-primary")#定位保存按钮
    set_locator = (By.CLASS_NAME, "avatar")#定位头像下拉框
    system_locator = (By.LINK_TEXT,"系统设置")#定位系统设置
    format_locator = (By.CSS_SELECTOR,".span6 > tbody:nth-child(2) > tr:nth-child(6) > td:nth-child(2) > input:nth-child(1)")
    #定位允许上传文件类型输入框
    safe_locator = (By.CSS_SELECTOR, ".alert")  # 定位系统设置保存后的成功提示语

    # 输入系统名称
    def set_name(self, title):
        '''
        先定位系统名称输入框，然后清空后输入新的参数
        :param title:
        :return:
        '''
        name = self.find_element(self.name_locator)
        name.clear()
        name.send_keys(title)

    # 输入系统描述
    def set_describe(self, text):
        '''
        先定位系统描述输入框，然后清空后输入新的参数
        :param title:
        :return:
        '''
        describe = self.find_element(self.describe_locator)
        describe.clear()
        describe.send_keys(text)

    # 上传系统logo
    def set_picture(self, picture):
        self.find_element(self.picture_locator).send_keys(picture)

    # 选择省份
    def set_provice(self, provice):
        '''
        先定位省份下拉框，然后输入自己需要的省份
        :param title:
        '''
        self.choice_select(self.provice_locator).select_by_visible_text(provice)

    # 选择城市
    def set_city(self, city):
        '''
        先定位城市下拉框，然后输入所在省份的城市
        :param title:
        :return:
        '''
        self.choice_select(self.city_locator).select_by_visible_text(city)

    # 设置合同提醒时间
    def set_time_pact(self, time_pact):
        '''
        先定位合同提醒输入框，然后清空后输入新的参数
        :param title:
        :return:
        '''
        time = self.find_element(self.time_pact_locator)
        time.clear()
        time.send_keys(time_pact)

    # 设置合同前缀
    def set_name_pact(self, name_pact):
        '''
        先定位合同前缀输入框，然后清空后输入新的参数
        :param title:
        :return:
        '''
        pact = self.find_element(self.name_pact_locator)
        pact.clear()
        pact.send_keys(name_pact)

    # 更改任务分配模式为：随意分配
    def click_change(self):
        self.find_element(self.change_locator).click()

    # 设置客户池回收周期
    def set_change_time_client(self, time_client_pack):
        '''
        先定位客户池回收周期输入框，然后清空后输入新的参数
        :param title:
        :return:
        '''
        client_pack = self.find_element(self.change_client_time_locator)
        client_pack.clear()
        client_pack.send_keys(time_client_pack)

    # 设置客户领取周期为本周
    def set_time_client(self,time_client):
        '''
        先定位客户领取周期下拉框，然后输入需要的周期，有本月、本周、本天三个选项
        :param title:
        :return:
        '''
        self.choice_select(self.time_client_locator).select_by_visible_text(time_client)

    # 设置客户领取限制次数
    def set_client_number(self, number_client):
        '''
        先定位客户领取限制次数输入框，然后清空后输入新的参数
        :param title:
        :return:
        '''
        xz = self.find_element(self.client_number_locator)
        xz.clear()
        xz.send_keys(number_client)

    # 设置线索池回收周期
    def set_clue_time(self, time_clue):
        '''
        先定位线索池回收周期输入框，然后清空后输入新的参数
        :param title:
        :return:
        '''
        ss = self.find_element(self.clue_time_locator)
        ss.clear()
        ss.send_keys(time_clue)

    # 点击保存系统信息
    def click_save(self):
        self.find_element(self.save_locator).click()

    # 点击页面右上角头像框
    def click_head(self):
        self.find_element(self.set_locator).click()

    # 在下拉框中点击系统设置
    def click_system(self):
        self.find_element(self.system_locator).click()

    #修改系统默认上传文件格式
    def set_format(self, format):
        '''
        先定位允许上传文件类型输入框，然后清空后输入新的参数
        :param title:
        :return:
        '''
        text = self.find_element(self.format_locator)
        text.clear()
        text.send_keys(format)

    #获取保存成功后的页面上的提示语
    def get_safe(self):
        return self.find_element(self.safe_locator).text.strip()
