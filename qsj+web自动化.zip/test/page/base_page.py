# 定义CRM系统父类
from selenium.webdriver.support.select import Select
class CRMFather():
    """
    所有页面类的基类
    """
    HOST = "http://192.168.3.42/crm"
    def __init__(self,driver,url=HOST):
        self.driver = driver
        self.url = url

    def find_element(self,locator):
        '''
        重新封装find_element()方法
        :param locator:
        :return:
        '''
        return self.driver.find_element(*locator)

    def find_elements(self,locator):
        '''
        重新封装find_elements()方法
        :param locator:
        :return:
        '''
        return self.driver.find_elements(*locator)

    def choice_select(self, locator):
        '''
        重新封装Select方法
        :param locator:
        :return:
        '''
        return Select(self.find_element(locator))

    def open(self):
        '''
        打开浏览器
        :return:
        '''
        self.driver.get(self.url)