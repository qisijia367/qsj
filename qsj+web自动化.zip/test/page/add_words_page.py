'''
添加字段页面添加新的字段,包括单行文本、多行文本、小数、编辑器、选项等
'''
from page.base_page import CRMFather
from selenium.webdriver.common.by import By
from time import sleep
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.alert import Alert
import ddt
@ddt.ddt
class CRMAddWordsData(CRMFather):
    '''
    定义添加字段页面定位器
    '''
    message_locator = (By.XPATH, "/html/body/div[7]/div[2]/form/table/tbody/tr[3]/td[2]/input[1]")#添加字段页面
    title_locator = (By.ID, "name")#定位字段标识名
    hint_locator = (By.NAME, "input_tips")#定位字段输入提示信息
    word_locator = (By.ID, "add")#定位添加字段
    code_locator = (By.XPATH, "//input[@name='is_validate' and @value='1']")#定位字段是否验证
    only_locator = (By.XPATH, "//input[@name='is_unique' and @value='1']")#定位字段是否唯一
    null_locator = (By.XPATH, "//input[@name='is_null' and @value='0']")#定位字段是否允许为空
    list_watch_locator = (By.XPATH, "//input[@name='in_index' and @value='1']")#定位字段是否列表页显示
    page_watch_locator = (By.XPATH, "//input[@name='in_add' and @value='0']")#定位字段是否添加页显示
    save_locator = (By.CSS_SELECTOR, "input.btn:nth-child(1)")#定位保存字段
    user_head_locator = (By.CLASS_NAME, "avatar")#定位头像下拉框
    system_locator = (By.LINK_TEXT,"系统设置")#系统设置页面
    module_locator = (By.LINK_TEXT, "模块字段设置")#模块字段设置
    words_locator = (By.ID, "add")#添加字段
    type_locator = (By.ID,"form_type")#定位字段类型
    business_name_locator = (By.LINK_TEXT, "商机字段设置")#商机页面
    product_name_locator = (By.LINK_TEXT, "产品字段设置")#产品页面
    clue_name_locator = (By.LINK_TEXT, "线索字段设置")#线索页面
    option_locator = (By.CSS_SELECTOR, "#box_type_td > td:nth-child(2) > input:nth-child(2)")#添加选项字段
    option_test_locator = (By.CSS_SELECTOR, "#box_data_td > td:nth-child(2) > textarea:nth-child(1)")#添加选项内容
    special_locator = (By.LINK_TEXT,"特殊设置")#定位字段中的特殊设置
    add_business_locat = (By.ID, "add")#定位添加商机
    business_title_locator = (By.CLASS_NAME, "span3")#定位添加商机名
    business_test_locator = (By.CLASS_NAME, "span4")#定位添加商机描述
    business_save_locator = (By.CSS_SELECTOR, "input.btn-primary")#定位商机类别保存
    product_add_locator = (By.ID, "add_category")#定位添加产品类别
    product_title_locator = (By.ID, "name")#定位添加产品名
    product_text_locator = (By.CLASS_NAME, "span4")#定位产品描述
    product_save_locator = (By.CSS_SELECTOR, "input.btn-primary:nth-child(1)")#定位产品类别保存
    delete_locator = (By.CSS_SELECTOR,".ui-sortable")#定位整个字段列表
    delete_tr_locator = (By.TAG_NAME, "tr")#定位字段中的每行
    delete_a_locator = (By.TAG_NAME, "a")#定位a标签
    delete_botton_locator = (By.CSS_SELECTOR, ".bulk-actions > button:nth-child(1)")#定位全部删除按钮
    delete_all_locator = (By.CSS_SELECTOR, "#check_all")#定位选择全部勾选框
    delete_one_locator = (By.LINK_TEXT,"删除")#定位页面中的删除项
    delete_input_locator = (By.TAG_NAME,"input")#定位input标签
    business_number_locator = (By.CSS_SELECTOR, ".ui-sortable")#定位商机状态框
    product_number_locator = (By.CSS_SELECTOR, ".table")#定位产品列表框
    add_words_number_locator = (By.CSS_SELECTOR, ".table")#定位字段框
    tr_locator = (By.TAG_NAME, "tr")#定位行
    add_words_clue_locator = (By.CSS_SELECTOR, ".ui-sortable > tr:nth-child(3) > td:nth-child(2)")#定位线索页面第三个字段
    add_words_client_locator = (By.CSS_SELECTOR, ".ui-sortable > tr:nth-child(2) > td:nth-child(2)")#定位线索页面第二个字段

    # 切换至商机字段设置页面
    def click_business(self):
        self.find_element(self.business_name_locator).click()

    # 切换至产品字段设置页面
    def click_product(self):
        self.find_element(self.product_name_locator).click()

    # 切换至线索字段设置页面
    def click_clue(self):
        self.find_element(self.clue_name_locator).click()

    # 打开添加字段页面
    def click_message(self):
        self.find_element(self.message_locator).click()

    # 输入标识名
    def set_title(self,title):
        self.find_element(self.title_locator).send_keys(title)

    # 输入“输入提示”信息
    def set_hint(self,text):
        self.find_element(self.hint_locator).send_keys(text)

    # 选择信息类型为：主要信息
    def click_word(self):
        self.find_element(self.word_locator).click()

    # 选择是否验证为：是
    def click_code(self):
        self.find_element(self.code_locator).click()

    # 选择是否唯一为：是
    def click_only(self):
        self.find_element(self.only_locator).click()

    # 选择是否允许为空为：否
    def click_null(self):
        self.find_element(self.null_locator).click()

    # 选择列表页显示为：是
    def click_list_watch(self):
        self.find_element(self.list_watch_locator).click()

    # 选择添加页显示为：否
    def click_page_watch(self):
        self.find_element(self.page_watch_locator).click()

    # 保存添加的字符
    def click_save(self):
        self.find_element(self.save_locator).click()

    # 点击页面右上角头像框
    def click_user_head(self):
        self.find_element(self.user_head_locator).click()

    # 点击系统设置
    def click_system(self):
        self.find_element(self.system_locator).click()

    # 点击模块字段设置
    def click_module(self):
        self.find_element(self.module_locator).click()

    # 点击添加字段
    def click_words(self):
        self.find_element(self.words_locator).click()
        sleep(1)

    # 输入字段类型，切换字段
    def set_multi_line(self, type):
        self.choice_select(self.type_locator).select_by_visible_text(type)

    # 选择选项为多选
    def click_option(self):
        self.find_element(self.option_locator).click()

    # 填写选项内容
    def set_option_test(self,test_one,test_two):
        '''
        输入选项内容，根据格式一排为一个选项
        :param test_one:
        :param test_two:
        :return:
        '''
        test = self.find_element(self.option_test_locator)
        test.send_keys(test_one)  # 添加选项
        test.send_keys(Keys.ENTER)  # 换行
        test.send_keys(test_two)  # 添加选项

    # 点击特殊设置
    def click_special(self):
        self.find_element(self.special_locator).click()
        sleep(1)

    # 添加商机状态
    def set_add_business(self):
        self.find_element(self.add_business_locat).click()
        sleep(1)

    # 添加商机状态名
    def set_business_title(self, title):
        self.find_element(self.business_title_locator).send_keys(title)

    # 添加商机状态描述
    def set_business_test(self, text):
        self.find_element(self.business_test_locator).send_keys(text)

    # 保存添加的商机状态
    def click_business_save(self):
        self.find_element(self.business_save_locator).click()

    # 添加产品类别
    def click_product_add(self):
        self.find_element(self.product_add_locator).click()
        sleep(1)

    # 添加产品类别名
    def set_product_title(self, title):
        self.find_element(self.product_title_locator).send_keys(title)

    # 添加产品类别描述
    def set_product_text(self, text):
        self.find_element(self.product_text_locator).send_keys(text)

    # 保存添加产品类别
    def click_product_save(self):
        self.find_element(self.product_save_locator).click()

    # 全选可以删除的非特殊字段
    def choice_delect_all_words(self):
        '''
        勾选可以单独点击删除的项，先确定每一行是否有删除按钮可以点击，
        如果有则在勾选中进行勾选选中
        :return:
        '''
        tbody = self.find_element(self.delete_locator)#确定模块
        tr = tbody.find_elements(*self.delete_tr_locator)#确定所有行
        for a in tr:
            lis = a.find_elements(*self.delete_a_locator)#查找每一行所有的a标签
            if "删除" == lis[1].text :#找到第二个a标签的文本为“删除”的项
                a.find_element(*self.delete_input_locator).click()#点击勾选框

    # 选择所有字段
    def choice_all_words(self):
        self.find_element(self.delete_all_locator).click()
        sleep(1)

    # 单击删除按钮进行单个字段删除
    def choice_one_delete(self):
        '''
        找到页面中第一个可以点击删除按钮的项，进行单独删除
        :return:
        '''
        tbody = self.find_element(self.delete_locator)
        tr = tbody.find_elements(*self.delete_tr_locator)
        for a in tr:
            lis = a.find_elements(*self.delete_a_locator)
            if "删除" == lis[1].text :#找到第二个a标签的文本为“删除”二字
                a.find_element(*self.delete_one_locator).click()#点击删除按钮
                sleep(2)
                confirm = Alert(self.driver)
                confirm.accept()#确认删除警告框
                sleep(2)
                break

    # 确认删除字段
    def click_delete(self):
        self.find_element(self.delete_botton_locator).click()
        sleep(2)
        confirm = Alert(self.driver)
        confirm.accept()#确认删除警告框
        sleep(2)

    # 返回页面商机状态数量
    def get_business(self):
        '''
        首先找到商机状态框，然后返回所有的行
        :return:
        '''
        business = self.find_element(self.business_number_locator)
        tr = business.find_elements(*self.tr_locator)
        return len(tr)

    # 返回页面商品的数目
    def get_product(self):
        '''
        首先找到商品类别框，然后返回所有的行
        :return:
        '''
        cp = self.find_element(self.product_number_locator)
        tr = cp.find_elements(*self.tr_locator)
        return len(tr)

    # 返回所有字段的数目
    def get_word(self):
        '''
        首先找到字段框，然后返回所有的字段行
        :return:
        '''
        wd = self.find_element(self.add_words_number_locator)
        tr = wd.find_elements(*self.tr_locator)
        return len(tr)

    # 返回商机和线索中的名称
    def get_clue_page_words(self):
        return self.find_element(self.add_words_clue_locator).text

    #返回客户和产品字段中的名称
    def get_add_client_words(self):
        return self.find_element(self.add_words_client_locator).text
