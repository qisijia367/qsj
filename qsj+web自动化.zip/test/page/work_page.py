'''
查看工作台各部门的信息，包括动态信息，日志信息，crm信息
'''
from page.base_page import CRMFather
from selenium.webdriver.common.by import By
class CRMWorkData(CRMFather):
    '''
    工作台页面操作
    '''
    pitcure_locator = (By.CSS_SELECTOR,"div.avatar01:nth-child(1) > a:nth-child(1)")#定位头像下拉框
    department_locator = (By.CLASS_NAME, "dynamiccate")#定位所有部门
    depart_locator = (By.TAG_NAME, "a")#定位a标签
    search_text_locator = (By.CLASS_NAME,"search-text")#定位搜索输入框
    search_botton_locator = (By.ID,"searchBtn")#定位搜索按钮
    search_log_locator = (By.XPATH,"/html/body/div[5]/div[2]/div[2]/form/div/ul[1]/li[2]/a")#定位日志动态按钮
    search_crm_locator = (By.CSS_SELECTOR,"ul.list0:nth-child(5) > li:nth-child(3) > a:nth-child(1)")#定位crm动态按钮

    # 点击页面右上角头像打开下拉框
    def click_user_pitcure(self):
        self.find_element(self.pitcure_locator).click()

    # 工作台切换部门页面
    def list_department(self):
        '''
        找到页面中所有的部门，并返回部门列表信息
        :return:
        '''
        test = self.find_element(self.department_locator)
        lis = test.find_elements(*self.depart_locator)
        return lis

    # 在工作台搜索框输入信息并搜索
    def set_search_text(self, text):
        '''
        在动态搜索框输入信息并进行搜索
        :return:
        '''
        self.find_element(self.search_text_locator).send_keys(text)
        self.find_element(self.search_botton_locator).click()

    # 切换至日志动态列表
    def click_log_text(self):
        self.find_element(self.search_log_locator).click()

    # 切换至crm动态列表
    def click_crm_text(self):
        self.find_element(self.search_crm_locator).click()