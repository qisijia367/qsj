'''
@author: 齐斯嘉
@software: SeleniumTest
@file: 用例编号CRM-ST-GZT-002
@time: 2020/3/19 20:17
@desc:
'''
import unittest
from cases.base_case import BaseCase
from page.work_page import CRMWorkData
from page.login_page import CRMUser
from page.index_page import CRMUserTest
from common.read_datas import read_datas_users
from common.logger import Logger
logger = Logger().logger
import ddt
@ddt.ddt
class CrmJobsWatch(BaseCase):
    @ddt.data(*read_datas_users("crm_login_datas.csv"))
    @ddt.unpack
    def test_gzt_jobs_watch(self,username,password):
        '''
        工作台搜索用户名，分别查看所有动态，日志动态，crm动态
        :return:
        '''
        url = "http://192.168.3.42/crm/index.php?m=dynamic&a=index"
        lp = CRMUser(self.driver, url)
        lp.open()
        # lp.get_login(username, password)  #登录成功
        search = CRMWorkData(self.driver)#实例化工作台操作
        search.set_search_text(username)#传入参数并搜索
        news = CRMUserTest(self.driver)
        all_news = news.get_gzt_search()#获取所有动态页面的元素
        search.click_log_text()#切换至日志页面
        log_news = news.get_gzt_search()#获取日志页面的元素
        self.assertNotEqual(all_news,log_news)#判断页面是否切换成功
        logger.info(all_news)
        logger.info(log_news)
        search.click_crm_text()#切换至crm动态页面
        crm_news = news.get_gzt_search()#获取crm页面的元素
        self.assertNotEqual(log_news,crm_news)#判断页面是否切换成功
        logger.info(all_news)
        logger.info(log_news)
if __name__ == "__main__" :
    unittest.main()