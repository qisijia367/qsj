'''
@author: 齐斯嘉
@software: SeleniumTest
@file: 用例编号CRM-ST-XTBS-001
@time: 2020/3/19 20:17
@desc:
'''
import unittest
from cases.base_case import BaseCase
from page.change_setting_page import CRMChangeWordsData
from page.login_page import CRMUser
from common.read_datas import read_datas_users
from common.logger import Logger
logger = Logger().logger
import ddt
@ddt.ddt
class CrmChangeSafe(BaseCase):
    @ddt.data(*read_datas_users("crm_change_safe_datas.csv"))
    @ddt.unpack
    def test_change_safe(self,username,password,picture,format,test):
        '''
        修改系统默认上传文件格式为png，保存后再次修改系统logo，上传格式为png的图片
        :return:
        '''
        url = "http://192.168.3.42/crm/index.php?m=setting&a=defaultInfo"
        lp = CRMUser(self.driver,url)
        lp.open()
        # lp.get_login(username,password)#登录成功
        words = CRMChangeWordsData(self.driver)#实例化系统信息操作页面
        # words.click_head()#点击头像下拉框
        # words.click_system()#进入系统设置页面
        words.set_format(format)#修改系统默认上传文件格式
        words.click_save()#保存
        words.set_picture(picture)#上传修改后的图片格式
        words.click_save()#保存
        save_name = words.get_safe()#获取保存成功后的页面信息
        self.assertIn(test,save_name)#判断是否保存成功
        logger.info(test)
        logger.info(save_name)
if __name__ == "__main__":
    unittest.main()