'''
@author: 齐斯嘉
@software: SeleniumTest
@file: 用例编号CRM-ST-XTBS-010
@time: 2020/3/19 20:17
@desc:
'''
import unittest
from cases.base_case import BaseCase
from page.add_words_page import CRMAddWordsData
from page.login_page import CRMUser
from common.read_datas import read_datas_users
from common.logger import Logger
logger = Logger().logger
import ddt
@ddt.ddt
class CrmAddDate(BaseCase):
    @ddt.data(*read_datas_users("crm_add_date_datas.csv"))
    @ddt.unpack
    def test_add_date(self,username,password,type,title,text):
        '''
        在商机字段页面添加日期字段，合法输入所有必填项
        :return:
        '''
        url = "http://192.168.3.42/crm/index.php?m=setting&a=fields"
        lp = CRMUser(self.driver,url)
        lp.open()
        # lp.get_login(username,password)#登录成功
        add = CRMAddWordsData(self.driver)#实例化增加字段页面操作
        # add.click_user_head()#点击头像下拉框
        # add.click_system()#选择系统设置
        # add.click_module()#选择模块字段设置
        add.click_business()#切换至商机页面
        old = add.get_word()#统计添加前的字段数
        logger.info(old)
        add.click_words()#添加字段
        add.set_multi_line(type)#选择字段类型为日期
        add.set_title(title)#添加字段标识名
        add.set_hint(text)#添加字段提示语
        add.click_save()#保存字段
        new = add.get_word()#统计添加后的字段
        logger.info(new)
        name = add.get_clue_page_words()#获取添加后的字段名
        self.assertEqual(title,name)#判断输入字段名是否正确
        self.assertEqual(old, new-1)#判断字段数量是否正确
if __name__ == "__main__" :
    unittest.main()