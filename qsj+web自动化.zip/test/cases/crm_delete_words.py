'''
@author: 齐斯嘉
@software: SeleniumTest
@file: 用例编号CRM-ST-XTBS-003
@time: 2020/3/19 20:17
@desc:
'''
import unittest
from cases.base_case import BaseCase
from page.add_words_page import CRMAddWordsData
from page.login_page import CRMUser
from common.read_datas import read_datas_users
from common.logger import Logger
logger = Logger().logger
import ddt
@ddt.ddt
class CrmOneLine(BaseCase):
    @ddt.data(*read_datas_users("crm_login_datas.csv"))
    @ddt.unpack
    def test_add_one_line(self,username,password):
        '''
        验证字段删除，包括单独删除按钮，全选删除，以及多选可删除项删除
        :return:
        '''
        url = "http://192.168.3.42/crm/index.php?m=setting&a=fields"
        lp = CRMUser(self.driver,url)
        lp.open()
        # lp.get_login(username,password)#登录成功
        add = CRMAddWordsData(self.driver)#实例化增加字段页面操作
        # add.click_user_head()#点击头像下拉框
        # add.click_system()#点击系统设置
        # add.click_module()#点击模块字段设置
        old_all = add.get_word() #统计所有字段
        add.choice_all_words()#全选所有字段
        add.click_delete()#单击删除按钮
        new_all = add.get_word() #统计勾选删除所有字段后的剩余字段
        self.assertEqual(old_all, new_all)  #判断全选删除
        logger.info(old_all)
        logger.info(new_all)
        add.choice_one_delete()#单击删除按钮删除一个可删除的字段
        normal = add.get_word()  # 统计剩余所有字段
        self.assertEqual(new_all-1,normal) #判断单个删除
        logger.info(new_all)
        logger.info(normal)
        add.choice_delect_all_words()#只选择可以删除的字段
        add.click_delete()#单击删除按钮
        new_normal = add.get_word()#统计删除完后的剩余字段
        self.assertNotEqual(old_all,new_normal)#判断删除所有可删除的字段
        logger.info(old_all)
        logger.info(new_normal)
if __name__ == "__main__" :
    unittest.main()