'''
@author: 齐斯嘉
@software: SeleniumTest
@file: 用例编号CRM-ST-GZT-001
@time: 2020/3/19 20:17
@desc:
'''
import unittest
from cases.base_case import BaseCase
from page.work_page import CRMWorkData
from page.login_page import CRMUser
from page.index_page import CRMUserTest
from time import sleep
from common.read_datas import read_datas_users
from common.logger import Logger
logger = Logger().logger
import ddt
@ddt.ddt
class CrmJobsWatch(BaseCase):
    @ddt.data(*read_datas_users("crm_login_datas.csv"))
    @ddt.unpack
    def test_gzt_jobs_watch(self,username,password):
        '''
        验证工作台页面不同部门之间的信息展示
        :return:
        '''
        url = "http://192.168.3.42/crm/index.php?m=dynamic&a=index"
        lp = CRMUser(self.driver, url)
        lp.open()
        # lp.get_login(username,password)#登录成功
        watch = CRMWorkData(self.driver)
        text = CRMUserTest(self.driver)
        depart = watch.list_department()#取出所有的部门
        for num in range(len(depart)):#循环点击部门列表
            old_news = text.get_news()#获取当前页面信息
            all_list = watch.list_department()
            all_list[num].click()
            new_news = text.get_news()#获取切换页面的信息
            sleep(1)
            self.assertNotEqual(old_news,new_news)#判断页面信息是否不同
            logger.info(old_news)
            logger.info(new_news)
if __name__ == "__main__" :
    unittest.main()