'''
@author: 齐斯嘉
@software: SeleniumTest
@file: 用例编号CRM-ST-XTBS-005
@time: 2020/3/19 20:17
@desc:
'''
import unittest
from cases.base_case import BaseCase
from page.add_words_page import CRMAddWordsData
from page.login_page import CRMUser
from common.read_datas import read_datas_users
from common.logger import Logger
logger = Logger().logger
import ddt
@ddt.ddt
class CrmAddBusniess(BaseCase):
    @ddt.data(*read_datas_users("crm_add_business_product_datas.csv"))
    @ddt.unpack
    def test_add_busniess(self,username,password,title,text):
        '''
        在商机字段页面点击特殊设置，进入添加商机状态页面，添加商机状态，合法输入商机状态标题和描述
        :return:
        '''
        url = "http://192.168.3.42/crm/index.php?m=setting&a=businessstatus&model=business"
        lp = CRMUser(self.driver,url)
        lp.open()
        # lp.get_login(username,password)#登录成功
        add = CRMAddWordsData(self.driver)#实例化增加字段页面操作
        # add.click_user_head()#点击头像下拉框
        # add.click_system()#点击系统设置
        # add.click_module()#点击模块字段设置
        # add.click_business()#跳转至商机页面
        # add.click_special()#点击特殊设置
        old = add.get_business()#统计添加前的字段数
        logger.info(old)
        add.set_add_business()#添加商机状态
        add.set_business_title(title)#设置商机状态名
        add.set_business_test(text)#设置商机状态描述
        add.click_business_save()#保存商机状态
        new = add.get_business()#统计添加后的字段数
        logger.info(new)
        self.assertEqual(old,new-1)
if __name__ == "__main__" :
    unittest.main()