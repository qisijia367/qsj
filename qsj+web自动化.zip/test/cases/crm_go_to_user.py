'''
@author: 齐斯嘉
@software: SeleniumTest
@file: 用例编号CRM-ST-GZT-003
@time: 2020/3/19 20:17
@desc:
'''
import unittest
from cases.base_case import BaseCase
from page.index_page import CRMUserTest
from page.login_page import CRMUser
from page.work_page import CRMWorkData
from common.read_datas import read_datas_users
from common.logger import Logger
logger = Logger().logger
import ddt
@ddt.ddt
class CrmUser(BaseCase):
    @ddt.data(*read_datas_users("crm_user_datas.csv"))
    @ddt.unpack
    def test_go_to_user(self,username,password,text):
        '''
        验证工作台页面点击头像跳转至修改个人信息页面
        :return:
        '''
        url = "http://192.168.3.42/crm/index.php?m=dynamic&a=index"
        lp = CRMUser(self.driver, url)
        lp.open()
        # lp.get_login(username,password)#登录成功
        work = CRMWorkData(self.driver)
        work.click_user_pitcure()#点击头像跳转页面
        name = CRMUserTest(self.driver)
        head = name.get_user()#获取个人信息页面的元素信息
        self.assertEqual(text,head)#判断页面是否跳转成功
        logger.info(text)
        logger.info(head)
if __name__ == "__main__" :
    unittest.main()