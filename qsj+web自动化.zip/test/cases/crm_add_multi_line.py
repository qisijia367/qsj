'''
@author: 齐斯嘉
@software: SeleniumTest
@file: 用例编号CRM-ST-XTBS-008
@time: 2020/3/19 20:17
@desc:
'''
import unittest
from cases.base_case import BaseCase
from page.add_words_page import CRMAddWordsData
from page.login_page import CRMUser
from common.read_datas import read_datas_users
from common.logger import Logger
logger = Logger().logger
import ddt
@ddt.ddt
class CrmAddMulti(BaseCase):
    @ddt.data(*read_datas_users("crm_add_multiline_datas.csv"))
    @ddt.unpack
    def test_add_multi_line(self,username,password,type,title,text):
        '''
        在线索页面添加多行文本字段，合法输入标识名、输入提示等参数
        '''
        url = "http://192.168.3.42/crm/index.php?m=setting&a=fields"
        lp = CRMUser(self.driver,url)
        lp.open()
        # lp.get_login(username,password)#登录成功
        add = CRMAddWordsData(self.driver)#实例化增加字段页面操作
        # add.click_user_head()#点击头像下拉框
        # add.click_system()#点击系统设置
        # add.click_module()#点击模块字段设置
        add.click_clue()#跳转至线索页面
        old = add.get_word()#获取添加前的字段数
        logger.info(old)
        add.click_words()#打开字段添加页面
        add.set_multi_line(type)#选择字段类型为多行文本
        add.set_title(title)#添加标识名
        add.set_hint(text)#添加字段提示语
        add.click_list_watch()#选择在列表页显示
        add.click_page_watch()#选择不在添加页显示
        add.click_save()#保存字段
        new = add.get_word()#获取添加后的字段数
        logger.info(new)
        name = add.get_clue_page_words()#获取新加的字段名
        self.assertEqual(title,name)#获取新加的字段名
        self.assertEqual(old,new-1)#判断字段数量是否正确
if __name__ == "__main__" :
    unittest.main()