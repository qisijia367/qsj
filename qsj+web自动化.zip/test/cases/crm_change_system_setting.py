'''
@author: 齐斯嘉
@software: SeleniumTest
@file: 用例编号CRM-ST-XTBS-002
@time: 2020/3/19 20:17
@desc:
'''
import unittest
from cases.base_case import BaseCase
from page.change_setting_page import CRMChangeWordsData
from page.login_page import CRMUser
from common.read_datas import read_datas_users
from common.logger import Logger
logger = Logger().logger
import ddt
@ddt.ddt
class CrmChangeSetting(BaseCase):
    @ddt.data(*read_datas_users("crm_change_system_datas.csv"))
    @ddt.unpack
    def test_change_setting(self,username,password,title,text,picture,provice,city,time_pact,name_pact,
                            time_client_pack,time_client,number_client,time_clue,jarge):
        '''
        修改系统设置，包括系统名，系统描述，系统logo，修改省份和城市
        以及合同时间，合同前缀，客户回收池，线索回收池等信息
        :return:
        '''
        url = "http://192.168.3.42/crm/index.php?m=setting&a=defaultInfo"
        lp = CRMUser(self.driver,url)
        lp.open()
        # lp.get_login(username,password)#登录成功
        words = CRMChangeWordsData(self.driver)#实例化系统信息操作页面
        # words.click_head()#点击头像下拉框
        # words.click_system()#进入系统设置页面
        words.set_name(title)#修改系统名
        words.set_describe(text)#修改系统描述
        words.set_picture(picture)#修改默认logo
        words.set_provice(provice)#修改省份
        words.set_city(city)#修改城市
        words.set_time_pact(time_pact)#修改合同时间
        words.set_name_pact(name_pact)#修改合同前缀名
        words.click_change()#修改任务分配模式
        words.set_change_time_client(time_client_pack)#修改客户池回收周期
        words.set_time_client(time_client)#修改客户领取周期
        words.set_client_number(number_client)#修改客户领取次数
        words.set_clue_time(time_clue)#修改线索池回收周期
        words.click_save()#保存设置
        name = words.get_safe()#获取保存成功后的页面信息
        self.assertIn(jarge, name)#判断是否保存成功
        logger.info(jarge)
        logger.info(name)
if __name__ == "__main__":
    unittest.main()