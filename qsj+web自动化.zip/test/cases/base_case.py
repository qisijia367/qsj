'''
设置用例执行前后的setUp和tearDown
'''
import unittest
from common.drive import Chrome
from common.read_datas import get_cookie
from common.path import *
class BaseCase(unittest.TestCase):
    #用例执行前调用Chrome浏览器
    def setUp(self):
        self.driver = Chrome()
        self.driver.get(HOST)
        self.driver.add_cookie(get_cookie('cookies.ini'))

    #用例执行完成退出浏览器
    def tearDown(self):
        self.driver.quit()